# Beginner's Guide to React Router Repo

> This tutorial uses React Router version 2.0.1

This goes along with the medium post [Beginner's Guide to React Router](https://medium.com/p/53094349669/)

**To get started with this project, do the following:**

1. Git clone the project
2. cd into the project directory
3. run `npm install` from the terminal
4. run `npm start` from the terminal

```
npm install
npm start
```