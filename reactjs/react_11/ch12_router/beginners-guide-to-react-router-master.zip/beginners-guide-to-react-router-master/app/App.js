import React, { Component } from 'react'
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router'

const App = () => <h1>Hello World!</h1>

export default App
